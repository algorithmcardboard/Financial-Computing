package edu.nyu.compfin14;

/**
 * Created by anirudhan on 5/8/15.
 */
public enum OrderAction {
    BUY, SELL, REPLACE
}
