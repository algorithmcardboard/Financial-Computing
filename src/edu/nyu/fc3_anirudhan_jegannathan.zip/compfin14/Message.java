package edu.nyu.compfin14;

/**
 * Created by anirudhan on 5/6/15.
 * Message interface for submitting a new order or a cancel order or a replace order
 */
public interface Message {

}